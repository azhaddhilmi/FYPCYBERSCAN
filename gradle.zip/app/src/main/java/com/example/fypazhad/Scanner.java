package com.example.fypazhad;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.blikoon.qrcodescanner.QrCodeActivity;
import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.zxing.Result;

import java.util.HashMap;
import java.util.Map;

public class Scanner extends AppCompatActivity {
    CodeScanner mCodeScanner;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;

    public static final int REQ_CODE_QR = 5152;
    public static final int CAMERA_REQ_CODE = 62;

    Button btnScan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanner);
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        btnScan = findViewById(R.id.btnScan);

        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scanCode();
            }
        });
    }

    private void scanCode() {
        if (canOpenCamera()) {
            openCamera();
        } else {
            requestCameraPermission();
        }
    }

    private boolean canOpenCamera() {

        int permission = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);

        if (permission == PackageManager.PERMISSION_GRANTED)
            return true;

        return false;
    }

    private void openCamera() {
        Intent intent = new Intent(Scanner.this, QrCodeActivity.class);
        startActivityForResult(intent, REQ_CODE_QR);
    }

    private void requestCameraPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
            Toast.makeText(this, "Permission required to access Camera", Toast.LENGTH_SHORT).show();
        }
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.CAMERA
        }, CAMERA_REQ_CODE);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == CAMERA_REQ_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            } else {
                Toast.makeText(this, "Permission is denied", Toast.LENGTH_SHORT).show();
            }
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if(resultCode != Activity.RESULT_OK){

            if(data == null)
                return;

            String result = data.getStringExtra("com.blikoon.qrcodescanner.error_decoding_image");
            Log.d("ERROR_RESULT", ""+result);
            if(result != null){
                AlertDialog dialog = new AlertDialog.Builder(Scanner.this).create();
                dialog.setTitle("Error Result");
                dialog.setMessage("QR CODE CANT BE SCANNED");

                dialog.setButton(AlertDialog.BUTTON_NEUTRAL, "QR",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int which) {
                                dialogInterface.dismiss();
                            }
                        });
                dialog.show();
            }
            return;
        }

        if (requestCode == REQ_CODE_QR){
            if ((data == null))
                return;

            String result = data.getStringExtra("com.blikoon.qrcodescanner.got_qr_scan_relult");
            Log.d("SCan_RESULT", ""+result);
            AlertDialog dialog = new AlertDialog.Builder(Scanner.this).create();
            dialog.setTitle("Scan Result");
            dialog.setMessage(result
            );



            dialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int which) {

                            String str = result;
                            Intent intent= new Intent (Scanner.this, MainActivity.class) ;
                                    intent.putExtra("key", str);
                            intent.putExtra("key", str);
                            startActivity(intent);

                            Toast.makeText( Scanner.this,  "User Created", Toast.LENGTH_SHORT).show();
                            String userID;
                            userID = fAuth.getCurrentUser().getUid();
                            DocumentReference documentReference = fStore.collection("users").document(userID);
                            Map<String,Object> user = new HashMap<>();
                            user.put("fName", fullName);
                            user.put("email", email);
                            user.put("Id", Id);
                            dialogInterface.dismiss();
                        }
                    });

            dialog.show();
        }
    }
}